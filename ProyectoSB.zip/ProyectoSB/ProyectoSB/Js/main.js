document.addEventListener('DOMContentLoaded', () => {
  // 🍔 Menú hamburguesa
  const menuToggle = document.querySelector('.menu-toggle');
  const navbar = document.querySelector('.navbar');

  menuToggle.addEventListener('click', () => {
    menuToggle.classList.toggle('active');
    navbar.classList.toggle('show');
  });

  // 👤 Cambiar entre cliente/admin (simulado)
  // Para producción: const userType = localStorage.getItem('userType') || 'cliente';
  const userType = 'cliente'; // ← cámbialo a 'admin' para ver el menú de admin
  const clienteView = document.querySelector('.user-type[data-type="cliente"]');
  const adminView = document.querySelector('.user-type[data-type="admin"]');

  if (userType === 'admin') {
    clienteView.style.display = 'none';
    adminView.style.display = 'block';
  }

  // 🚪 Cerrar sesión
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
      e.preventDefault();
      alert('Sesión cerrada');
      // localStorage.removeItem('userType');
      // window.location.href = 'index.html';
    });
  }

  console.log('Matcha Salon cargado ✅');
});