document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('login-form');

  loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // Simular login (en producción, esto iría a la API C#)
    if (email && password) {
      alert(`Bienvenido/a ${email}!`);
      // Redirigir a la página de inicio o dashboard
      window.location.href = 'index.html';
    } else {
      alert('Por favor completa todos los campos.');
    }
  });
});