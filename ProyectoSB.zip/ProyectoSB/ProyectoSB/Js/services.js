document.addEventListener('DOMContentLoaded', () => {

  const services = [
    {
      id: 1,
      name: "Corte de cabello",
      description: "Corte personalizado según tu estilo y tipo de cabello.",
      category: "cabello",
      duration: "45 min",
      price: 15
    },
    {
      id: 2,
      name: "Tinte",
      description: "Aplicación de color profesional con tratamiento post-color.",
      category: "cabello",
      duration: "90 min",
      price: 90
    },
    {
      id: 3,
      name: "Manicure clásico",
      description: "Limpieza, corte, limado, retiro de cutículas y esmaltado.",
      category: "uñas",
      duration: "40 min",
      price: 12000
    },
    {
      id: 4,
      name: "Manicure con rubber base",
      description: "Base fortalecedora + esmaltado semipermanente o diseño.",
      category: "uñas",
      duration: "60 min",
      price: 30
    },
    {
      id: 5,
      name: "Uñas con polygel",
      description: "Aplicación con molde o tip, curado UV/LED, limado y decoración.",
      category: "uñas",
      duration: "90 min",
      price: 35
    },
    {
      id: 6,
      name: "Tratamiento facial básico",
      description: "Limpieza profunda, exfoliación, hidratación y masaje.",
      category: "faciales",
      duration: "60 min",
      price: 80
    },
    {
      id: 7,
      name: "Maquillaje natural",
      description: "Ideal para día a día o eventos casuales.",
      category: "maquillaje",
      duration: "45 min",
      price: 60
    },
    {
      id: 8,
      name: "Maquillaje de fiesta",
      description: "Completo, con durabilidad extendida y diseño personalizado.",
      category: "maquillaje",
      duration: "75 min",
      price: 75
    }
  ];

  const servicesGrid = document.getElementById('services-grid');
  const categoryFilter = document.getElementById('category-filter');

  function renderServices(filter = 'all') {
    servicesGrid.innerHTML = '';
    const filtered = filter === 'all' ? services : services.filter(s => s.category === filter);

    filtered.forEach(service => {
      const card = document.createElement('div');
      card.className = 'card service-card';
      card.innerHTML = `
        <span class="category">${capitalize(service.category)}</span>
        <h3>${service.name}</h3>
        <p class="service-desc">${service.description}</p>

        <div class="meta">
          <span class="duration">⏱ ${service.duration}</span>
          <span class="price">₡${service.price.toLocaleString()}</span>
        </div>
      `;
      servicesGrid.appendChild(card);
    });
  }

  function capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
  }

  categoryFilter.addEventListener('change', (e) => {
    renderServices(e.target.value);
  });

  renderServices();
});
