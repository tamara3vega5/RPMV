document.addEventListener('DOMContentLoaded', () => {
  // Estado de la reserva
  const bookingData = {
    branch: null,
    stylist: null,
    service: null,
    date: null,
    time: null,
    name: null,
    phone: null,
    email: null
  };

  // Datos simulados
  const branches = ['central', 'almirante', 'via-espana'];
  
  const stylists = {
    central: [
      { id: 1, name: 'Emilia', specialty: 'cabello', img: 'https://via.placeholder.com/300x200?text=Tamara' },
      { id: 2, name: 'Antonella', specialty: 'uñas', img: 'https://via.placeholder.com/300x200?text=Hilda' },
      { id: 3, name: 'Sofía', specialty: 'faciales', img: 'https://via.placeholder.com/300x200?text=Sofia' }
    ],
    almirante: [
      { id: 4, name: 'Carlos', specialty: 'cabello', img: 'https://via.placeholder.com/300x200?text=Carlos' },
      { id: 5, name: 'Ana', specialty: 'maquillaje', img: 'https://via.placeholder.com/300x200?text=Ana' }
    ],
    'via-espana': [
      { id: 6, name: 'Lucía', specialty: 'uñas', img: 'https://via.placeholder.com/300x200?text=LUCIA' },
      { id: 7, name: 'Diego', specialty: 'faciales', img: 'https://via.placeholder.com/300x200?text=Diego' }
    ]
  };

  const servicesBySpecialty = {
    cabello: [
      { id: 1, name: 'Corte de cabello', duration: 45, price: $25 },
      { id: 2, name: 'Tinte', duration: 90, price: $50 }
    ],
    uñas: [
      { id: 3, name: 'Manicure clásico', duration: 40, price: $25 },
      { id: 4, name: 'Manicure con rubber base', duration: 60, price: $30},
      { id: 5, name: 'Uñas con polygel', duration: 90, price: $35 }
    ],
    faciales: [
      { id: 6, name: 'Tratamiento facial básico', duration: 60, price: $60 }
    ],
    maquillaje: [
      { id: 7, name: 'Maquillaje natural', duration: 45, price: $45 },
      { id: 8, name: 'Maquillaje de fiesta', duration: 75, price: $65 }
    ]
  };

  // Elementos
  const steps = document.querySelectorAll('.step');
  const stepContents = document.querySelectorAll('.step-content');
  const next1Btn = document.getElementById('next-1');
  const next2Btn = document.getElementById('next-2');
  const next3Btn = document.getElementById('next-3');
  const back2Btn = document.getElementById('back-2');
  const back3Btn = document.getElementById('back-3');
  const back4Btn = document.getElementById('back-4');
  const datetimeForm = document.getElementById('datetime-form');
  const timeSelect = document.getElementById('time');
  const dateInput = document.getElementById('date');
  const nameInput = document.getElementById('name');
  const phoneInput = document.getElementById('phone');
  const emailInput = document.getElementById('email');

  // Configurar fecha mínima (hoy)
  const today = new Date().toISOString().split('T')[0];
  dateInput.min = today;

  // Paso 1: Seleccionar sucursal
  document.querySelectorAll('.option-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.option-btn').forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
      bookingData.branch = btn.dataset.value;
      next1Btn.disabled = false;
    });
  });

  next1Btn.addEventListener('click', () => goToStep(2));
  back2Btn.addEventListener('click', () => goToStep(1));
  back3Btn.addEventListener('click', () => goToStep(2));
  back4Btn.addEventListener('click', () => goToStep(3));

  // Paso 2: Cargar y seleccionar estilista
  function goToStep(stepNum) {
    // Actualizar stepper visual
    steps.forEach(s => s.classList.remove('active'));
    steps[stepNum - 1].classList.add('active');

    // Mostrar contenido
    stepContents.forEach(c => c.classList.remove('active'));
    document.getElementById(`step-${stepNum}`).classList.add('active');

    // Acciones específicas por paso
    if (stepNum === 2) {
      loadStylists();
    }
    if (stepNum === 3) {
      loadServices();
    }
    if (stepNum === 4) {
      loadTimeSlots();
    }
  }

  function loadStylists() {
    const grid = document.getElementById('stylists-grid');
    const instruction = document.getElementById('stylist-instruction');
    
    if (!bookingData.branch) {
      instruction.textContent = '⚠️ Debes seleccionar una sucursal primero.';
      grid.innerHTML = '';
      return;
    }

    instruction.textContent = `Estilistas disponibles en ${bookingData.branch === 'central' ? 'Central' : bookingData.branch === 'almirante' ? 'Almirante' : 'Vía España'}:`;
    grid.innerHTML = '';

    stylists[bookingData.branch].forEach(stylist => {
      const card = document.createElement('div');
      card.className = 'card';
      card.innerHTML = `
        <img src="${stylist.img}" alt="${stylist.name}">
        <h3>${stylist.name}</h3>
        <p>Especialidad: ${stylist.specialty}</p>
        <button class="select-stylist" data-id="${stylist.id}" data-name="${stylist.name}" data-specialty="${stylist.specialty}">
          Seleccionar
        </button>
      `;
      grid.appendChild(card);
    });

    // Eventos para seleccionar estilista
    document.querySelectorAll('.select-stylist').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.select-stylist').forEach(b => b.textContent = 'Seleccionar');
        btn.textContent = '✓ Seleccionado';
        bookingData.stylist = {
          id: btn.dataset.id,
          name: btn.dataset.name,
          specialty: btn.dataset.specialty
        };
        next2Btn.disabled = false;
      });
    });
  }

  // Paso 3: Cargar servicios según especialidad
  function loadServices() {
    if (!bookingData.stylist) return;

    const grid = document.getElementById('services-selection');
    grid.innerHTML = '';

    const services = servicesBySpecialty[bookingData.stylist.specialty] || [];
    services.forEach(service => {
      const card = document.createElement('div');
      card.className = 'card';
      card.innerHTML = `
        <h3>${service.name}</h3>
        <p>Duración: ${service.duration} min • ₡${service.price.toLocaleString()}</p>
        <button class="select-service" 
          data-id="${service.id}" 
          data-name="${service.name}"
          data-duration="${service.duration}"
          data-price="${service.price}">
          Seleccionar
        </button>
      `;
      grid.appendChild(card);
    });

    document.querySelectorAll('.select-service').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.select-service').forEach(b => b.textContent = 'Seleccionar');
        btn.textContent = '✓ Seleccionado';
        bookingData.service = {
          id: btn.dataset.id,
          name: btn.dataset.name,
          duration: btn.dataset.duration,
          price: Number(btn.dataset.price)
        };
        next3Btn.disabled = false;
      });
    });
  }

  // Paso 4: Cargar horarios disponibles
  function loadTimeSlots() {
    timeSelect.innerHTML = '<option value="">Selecciona una hora</option>';
    // Simulamos horarios cada 30 min entre 8am y 6pm
    const start = 8;
    const end = 18;
    for (let h = start; h < end; h++) {
      for (let m of ['00', '30']) {
        const timeStr = `${h.toString().padStart(2, '0')}:${m}`;
        const option = document.createElement('option');
        option.value = timeStr;
        option.textContent = timeStr;
        timeSelect.appendChild(option);
      }
    }
  }

  // Formulario fecha/hora y datos personales
  datetimeForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const date = dateInput.value;
    const time = timeSelect.value;
    const name = nameInput.value;
    const phone = phoneInput.value;
    const email = emailInput.value;

    if (!date || !time || !name || !phone || !email) {
      alert('Por favor completa todos los campos.');
      return;
    }

    bookingData.date = date;
    bookingData.time = time;
    bookingData.name = name;
    bookingData.phone = phone;
    bookingData.email = email;

    // Mostrar confirmación
    showConfirmation();
  });

  function showConfirmation() {
    const summary = document.getElementById('summary');
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const dateObj = new Date(bookingData.date);
    const formattedDate = dateObj.toLocaleDateString('es-ES', options);

    summary.innerHTML = `
      <p><strong>Sucursal:</strong> ${bookingData.branch}</p>
      <p><strong>Estilista:</strong> ${bookingData.stylist.name}</p>
      <p><strong>Servicio:</strong> ${bookingData.service.name}</p>
      <p><strong>Fecha:</strong> ${formattedDate}</p>
      <p><strong>Hora:</strong> ${bookingData.time}</p>
      <p><strong>Nombre:</strong> ${bookingData.name}</p>
      <p><strong>Teléfono:</strong> ${bookingData.phone}</p>
      <p><strong>Email:</strong> ${bookingData.email}</p>
    `;

    document.getElementById('step-4').style.display = 'none';
    document.getElementById('confirmation').style.display = 'block';
  }

  // Inicial: Paso 1 activo
  goToStep(1);
});