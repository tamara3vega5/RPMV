document.addEventListener('DOMContentLoaded', () => {
  // Datos simulados (luego vendrán de la API o localStorage)
  const stylists = [
    { id: 1, name: 'Emilia', specialty: 'cabello', appointments: 12, revenue: 280000 },
    { id: 2, name: 'Antonella', specialty: 'uñas', appointments: 18, revenue: 324000 },
    { id: 3, name: 'Sofía', specialty: 'faciales', appointments: 6, revenue: 132000 },
    { id: 4, name: 'Carlos', specialty: 'cabello', appointments: 10, revenue: 225000 }
  ];

  // Comisión: 30% del ingreso por estilista
  const commissionRate = 0.30;

  // Actualizar resumen
  document.getElementById('stylists-count').textContent = stylists.length;
  document.getElementById('appointments-today').textContent = stylists.reduce((sum, s) => sum + s.appointments, 0);
  const totalRevenue = stylists.reduce((sum, s) => sum + s.revenue, 0);
  document.getElementById('revenue-today').textContent = `₡${totalRevenue.toLocaleString()}`;

  // Renderizar comisiones
  const list = document.getElementById('commissions-list');
  const cards = stylists.map(s => {
    const commission = s.revenue * commissionRate;
    return `
      <div class="card">
        <h3>${s.name}</h3>
        <p><strong>Especialidad:</strong> ${s.specialty}</p>
        <p><strong>Citas:</strong> ${s.appointments}</p>
        <p><strong>Ingresos:</strong> ₡${s.revenue.toLocaleString()}</p>
        <p><strong>Comisión (${Math.round(commissionRate * 100)}%):</strong> ₡${commission.toLocaleString()}</p>
      </div>
    `;
  }).join('');

  list.innerHTML = `<div class="cards-grid">${cards}</div>`;
});